## docker安装

1. 访问Docker官网文档，按需下载对应版本安装
`https://docs.docker.com/get-docker/`

2. 注册docker id
`https://hub.docker.com/signup`

3. 安装后点击工具栏的Docker图标，使用注册的docker id登录