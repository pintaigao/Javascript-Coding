console.log("abc");

let count: number = 30
console.log("count:", count);
console.log("count2:", count);
