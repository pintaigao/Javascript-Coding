console.log("kk");

let count: number = 23
console.log("count:", count);

export { }
