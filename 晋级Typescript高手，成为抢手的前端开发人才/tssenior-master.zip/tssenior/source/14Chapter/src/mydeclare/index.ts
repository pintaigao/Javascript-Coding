import { price } from './product.js'

console.log(price)