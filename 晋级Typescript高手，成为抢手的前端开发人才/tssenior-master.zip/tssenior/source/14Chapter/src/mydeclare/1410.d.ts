
declare function my(one: number, two: number): void
