import { mounted, IncreaseBoolean } from './148'

mounted(true);
let data: IncreaseBoolean = 0

export class Customer {
  constructor() {

  }
  buy() {
    let map = new Map<string, string>()
    map.set("abc", "Df");
  }
}
