import $ from 'JQueryModule'


$(function () {

})

$("div").css("border", "1px solid red").css("position", "relative");