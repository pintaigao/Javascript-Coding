import MyLocalStorage from './Mylocalstorage'

let obj = MyLocalStorage.getInstance();
let localstorage = new MyLocalStorage()
//localstorage.
