
class Ink {

  show(): void {

  }

}