class NeedleTypePrinter { // 针式打印机

  paper!: Paper
  print() {

  }
}

export { }