class B5Paper extends Paper {

  show() {
    console.log("B5Paper...");
  }
}