class A4Paper extends Paper {

  show() {
    console.log("A4Paper...");
  }
}