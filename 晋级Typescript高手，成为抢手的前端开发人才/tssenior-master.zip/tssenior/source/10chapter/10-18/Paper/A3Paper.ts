class A3Paper extends Paper {

  show() {
    console.log("A3Paper...");
  }


}