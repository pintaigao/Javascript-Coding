class NeedleTypePrinter { // 针式打印机

  paper: A4Paper = new A4Paper();

  print() {

  }
}
