

class Paper {
  show() {

  }
}