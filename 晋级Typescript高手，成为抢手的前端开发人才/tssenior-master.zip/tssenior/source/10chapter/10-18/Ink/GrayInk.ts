class GrayInk {
  show(): void {
    console.log("灰色墨盒....");
  }
}