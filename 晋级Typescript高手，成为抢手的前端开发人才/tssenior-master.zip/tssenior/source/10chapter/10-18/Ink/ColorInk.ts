class ColorInk {
  show(): void {
    console.log("彩色墨盒....");
  }
}