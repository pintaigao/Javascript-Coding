export default interface Userinfo {
  username: string,
  psd: string,
  phone: string,
  role: string
  mark: string
}