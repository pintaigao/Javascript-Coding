type MethodType = "get" | "post"

export default MethodType