import List from './List'
// 双向链表类中
class LinkedList<T> implements List<T>{
  getArray(): T[] {
    throw new Error('Method not implemented.');
  }
  add(ele: T): void {
    throw new Error('Method not implemented.');
  }
  get(index: number): T {
    throw new Error('Method not implemented.');
  }
  size(): number {
    throw new Error('Method not implemented.');
  }
  remove(value: T): T {
    throw new Error('Method not implemented.');
  }


}