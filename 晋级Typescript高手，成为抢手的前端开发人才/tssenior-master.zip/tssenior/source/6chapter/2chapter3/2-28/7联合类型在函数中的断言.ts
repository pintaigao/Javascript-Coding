

function selfMutiply(one: string | number) {
    //one as number +3;
}