export default class searchHistory {

}