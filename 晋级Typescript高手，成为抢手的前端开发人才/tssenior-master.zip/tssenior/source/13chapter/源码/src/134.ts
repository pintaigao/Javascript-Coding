//13-4 any 和 unknown 的两个区别
let price:any="abc"
let total:number=price

let stuObj:any={username:"wangwu",age:23}


let stuName:unknown={username:"wangwu",age:23}
// stuName.username

//let stuAge:number=stuName


export { }