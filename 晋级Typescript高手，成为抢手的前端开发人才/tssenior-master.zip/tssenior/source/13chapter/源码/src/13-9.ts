// let obj = { username: "wangwu", age: 23 }


// const username = "username"


// obj[username]


let obj: object = { username: "wangwu", age: 23 }


const username = "username"


let result = (obj as any)[username]