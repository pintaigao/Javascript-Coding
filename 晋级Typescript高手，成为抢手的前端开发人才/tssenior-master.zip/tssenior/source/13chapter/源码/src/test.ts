let obj = { username: "2d" }


export default class Customer {

}
export { }