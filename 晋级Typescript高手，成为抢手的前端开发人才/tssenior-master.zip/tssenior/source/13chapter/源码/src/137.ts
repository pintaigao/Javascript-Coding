// 13-7  string 和 String 的比较

let str:string="abc"





