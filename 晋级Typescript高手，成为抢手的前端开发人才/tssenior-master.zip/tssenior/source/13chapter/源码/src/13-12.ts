// // 数字枚举
// enum Week {
//   Monday = 1,
//   Tuesday,
//   Wensday,
//   ThirsDay,
//   Friday,
//   Sarturday,
//   Sunday
// }

// console.log(Week.Monday)
// console.log(Week["Monday"])

// console.log(Week[1])
// console.log(Week[5])



//  字符串枚举
enum WeekEnd {
  Monday = "Monday",
  Tuesday = "Tuesday",
  Wensday = "Wensday",
  ThirsDay = "ThirsDay",
  Friday = "Friday",
  Sarturday = "Sarturday",
  Sunday = "Sunday"
}

console.log(WeekEnd.Monday)
console.log(WeekEnd["Monday"])

export { }