# ELK-DEMO

Elk demo for nodejs log using docker,express and typescript.

## RUN

```bash
$ npm install
$ npm run build
$ npm start // another bash
```

## ELK

```bash
$ git clone https://github.com/deviantony/docker-elk.git
$ docker-compose up [-d]
```